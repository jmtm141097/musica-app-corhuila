const hbs = require('hbs');
const prettyJson = require('handlebars-prettyjson');

prettyJson(hbs);